import 'dart:ui';

class SYWCColors {
  static const PrimaryColor = Color(0xFF1D6738);
  static const PrimaryAccentColor = Color(0xFF0C132C);
  static const PrimaryLightColor = Color(0xFFB9CE33);
  static const ErroColor = Color(0xFF808080);
}
