import 'package:meta/meta.dart';

@immutable
abstract class RealtimeNotifierEvent {}
