import 'package:meta/meta.dart';

@immutable
abstract class RealtimeNotifierState {}
  
class InitialRealtimeNotifierState extends RealtimeNotifierState {}
