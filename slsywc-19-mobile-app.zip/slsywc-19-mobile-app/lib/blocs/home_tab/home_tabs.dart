enum HomeTabs { TimelineTab, FriendsTab, MeTab, PrizeTab }
