class CodeParsingException implements Exception {
  final String msg;

  CodeParsingException(this.msg);
}
