class DataFetchException implements Exception {
  final String msg;

  DataFetchException(this.msg);
}
