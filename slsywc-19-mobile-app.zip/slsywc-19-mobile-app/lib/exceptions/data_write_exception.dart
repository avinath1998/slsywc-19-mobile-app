class DataWriteException implements Exception {
  final String msg;

  DataWriteException(this.msg);
}
