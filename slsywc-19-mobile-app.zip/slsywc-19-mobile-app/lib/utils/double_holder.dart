class DoubleHolder {
  double value = 0.0;
}
