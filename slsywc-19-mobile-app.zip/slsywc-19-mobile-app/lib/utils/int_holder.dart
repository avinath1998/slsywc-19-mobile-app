class IntHolder {
  int value = 0;
}
